Project Name: LiSa

Team Members:
Sashank Gondala, 120050050
Krishna Deepak, 120050057
Bharath Kumar, 120050058
Bharadwaj, 120050056

Project Description:
The bot needs to find its way to a pre-set destination point in a given maze. We can place many barriers in its way and the bot needs to reach the destination in spite of these obstacles.