Group A 
Sashank Gondala, 120050050
Bharath Kumar, 120050058

Group B
Krishna Deepak, 120050057
Bharadwaj, 120050056

Add a well documented and commented code of your experiments in the respective folders.
