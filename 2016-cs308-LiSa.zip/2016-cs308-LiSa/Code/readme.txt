2016 - CS308  :Project README TEMPLATE 
================================================ 
 
Group Info: 
------------ 
Sashank Gondala, 120050050
Krishna Deepak, 120050057
Bharath Kumar, 120050058
Bharadwaj, 120050056

Extension Of 
------------ 
Nothing.

Project Description 
------------------- 
 
The bot needs to find its way to a pre-set destination point in a given maze. We can place many barriers in its way and the bot needs to reach the destination in spite of these obstacles.

Technologies Used 
------------------- 
 
Remove the items that do no apply to your project and keep the remaining ones. 
 
+   Embedded C 
 
 
Installation Instructions 
========================= 
Nothing is required
 
Demonstration Video 
=========================  
https://www.youtube.com/watch?v=VVdn_vI5sbc&feature=youtu.be

References 
=========== 
We have referred to manuals provided in erts website.
